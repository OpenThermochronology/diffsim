#!/bin/bash

# this version is companion to diffsim code; needs to be in same directory; plots from a temp file

gmt gmtset PS_CHAR_ENCODING ISOLatin1+   # easier to get symbols if you use ISOLATIN1+
gmt gmtset FONT_ANNOT_PRIMARY 10p,Helvetica,black  # numbers on axes
gmt gmtset FONT_LABEL 10p,Helvetica,black   # text labels on axes

target=diffsim-results.ps  #  output file name
proj=X8c # X is the Cartesian projection; our plot will be 8 cm wide
range=200/1200/0/0.01  # plot range for X and Y. 

# df plot

gmt psbasemap -J$proj -R$range -Xc -Y20c -Bxa100f50+l"Temperature (\260C)" -Bya0.001f0.005+l"df/\260C" -BWSne -P -K > $target

awk '{print $1,$2}' ../temp.out | gmt psxy -A -J$proj -R$range -Sc0.2c -Gorange -W1.1p,black -N -O -P -K >> $target

# arrhenius plot

range=8/20/-20/0

gmt psbasemap -J$proj -R$range -X -Yr-10c -Bxa2f0.5+l"10 000 / K" -Bya2.0f0.5+l"-ln D/a2" -BWSne -P  -O -K >> $target

awk '{print $3,$4}' ../temp.out | gmt psxy -J$proj -R$range -Sc0.2c -Gorange -W1.1p,black -O -P >> $target

# Convert the .ps file to pdf, using Ghostscript if it's installed

#ps2pdf $target 

gmt psconvert $target -Tf -Z

open diffsim-results.pdf



