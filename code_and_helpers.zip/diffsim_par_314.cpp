/* Program diffsim_par v. 3.14   16 March 2022
				
THIS VERSION USES the PCG RNG and (appears to) use OpenMP

	AUTHOR:	Dr. Peter K. Zeitler
			Department of Earth and Environmental Sciences
			Lehigh University - STEPS Building
			1 West Packer Avenue
			Bethlehem, Pennsylvania  18015-3188	U.S.A.
			+1 (610) 758-3671
			peter.zeitler@lehigh.edu

------------------------------------------------------------------------------------------------------
    PURPOSE:  Simulate diffusion at atom level to examine how CRH analysis can produce secondary peaks
    		from reversible sinks for radiogenic He that then act as point sources at higher temperatures. 
    		  
    		  Conventions and inputs:
    		  1. This uses a random walk in 3D, with 6-coordination for jumps, using spherical geometry
    		  2. Jumps are limited to x, y, and z Cartesian directions only; origin is 0,0,0.
    		  3. We assume no interaction and permit more than one atom at a site; sink sites can also hold multiple
    		  atoms and there can be multiple sinks at one location (illogical but makes no difference for our purposes).
    		  4. Atoms just at a surface node are still considered part of the crystal
    		  5. Master loop is a time loop that controls the thermal history (first in geological setting, then in lab)
    		  6. Atoms are produced at random locations to give a constant radiogenic production rate calibrated to not
    		  	 overwhelm with numbers (e.g., we're talking 1e5 to 1e6 total atoms since we have to track locations!).
    		  	 This production rate is constant and NOT scaled for depletion of parent, so technically this code
    		  	 only applies to "shorter" time intervals. "Ages" are just calculated as a simple ratio of (atoms left)
    		  	 over (atoms produced).
			  7. Number of jumps every atom takes at each time step is an exponential function of temperature, connecting
			     the Einstein formula for D to the Arrhenius law.
			  8. The point is NOT to quantitatively simulate He release from the mineral apatite, but instead, just to
			  	 explore the trapping behavior seen using CRH analysis. That said, parameters can be tuned to produce maximum
			  	 gas release at temperatures similar to those seen for apatite. 
			  9. Code is written for spherical geometry: the 3D cubical grid is clipped at the specified spherical radius.
			 10. Current code is pretty lazy and greedy about explicitly dimensioning arrays and vectors on the stack.
			 	 Attempts to significantly increase the number of walkers may need to use dynamic memory allocation and the heap.
			 11. The code uses extremely large numbers of random numbers, so it uses the high-quality PCG RNG. 
			 12. This code (3.14) addresses multiple cores using openMP to parallelize the atom-jumping loop. Thread safety
			 	 is a large issue for many RNGs, beyond my skill, really. This version places a new instance of the RNG
			 	 in each parallel block, and _appears_ to be functioning correctly without race conditions or problems with
			 	 each instance of the RNG.
			  			  
			  IMPORTANT NOTE: Because we have to keep a limit on the number of diffusion jumps while also tracking a 
			  sizable number of walkers, it is not feasible to simulate typical crystal dimensions and true jump distances.
			  Moreover, by treating atom locations and jumps as integers, the code is probably faster than if floating-point
			  calculations and logic were needed to track and move atoms. Fundamentally, the code uses fewer larger jumps 
			  and compensates by using a D value scaled to make that work.
			  
			  This means that the grain radius is determined by the number of radial nodes, and the jump distance will
			  be HUGE compared to the grain size. This will seem odd but does scale (but is another reason that this is
			  not a true simulation of He diffusion apatite!). To most easily scale things, it is best to think of the
			  node separation and the jump distance as 1 cm. Then, a D value can be found that produces
			  Do/a2 values typical for apatite. This also means that whenever the number of nodes is changed, Do must
			  be scaled accordingly!! Increasing the number of nodes produces better results for small diffusional losses
			  but the number of jumps scales with the ratio of nodes squared. Also, more sinks are needed to remain in scale
			  but trapping into and out of sinks is computationally costly.
			     	  			
   	  		  Tests done as I built this:
   	  		  1. Check that random walk is working. YES
   	  		  2. Experiment to tune parameters to get sensible diffusion and production rates, Dt/a2, grid size etc. YES
   	  		  2a. And be sure that those parameters lead to reasonable runs: decent number of jumps - don't want a 		
   	  		      zillion jumps for each atom but want enough to fully simulate a nice random walk. YES
   	  		  3. Run a special case where we look at outgassing for some given Dt/a2 values to see if fractional loss values match
   	  		     theory for spherical geometry. YES (analogous to finite difference code, accuracy for very low losses
   	  		     improves with the number of nodes).
   	  		  4. Run a slow linear cooling case to simulate closure; tune Tc; see if it responds correctly to cooling
   	  		  	 rate YES
   	  		  5. Add lab CRH degassing routine YES
   	  		  6. Add trap routines for bookkeeping and most important, for proper release with higher E. YES
   	  		  7. For version 3, add the ability to have up to 10 different trap types. YES
    		  
    		  This code originally used a version of the fast, decent-quality KISS random number generator.
    		       http://www0.cs.ucl.ac.uk/staff/d.jones/GoodPracticeRNG.pdf    -- JKISS32
			  It now uses the slightly faster PCG suite of RNG's - these are brought in via an include file. See 	
			  www.pcg-random.org
    		  
COMPILATION:  g++ diffsim_par_314.cpp -o diffsim3_m2 -fopenmp -Ofast -march=native
    		      		  
	USAGE:  ./diffsim3
	OUTPUT: some tab-delimited output files for tracking, plus a .pdf file produced by a bash script that uses gmt to plot
	the CRH release pattern and the Arrhenius plot.
	
	REQUIRED HELPER FILES
	compilation: pcg_random.hpp   pcg_extras.hpp
	execution: the input files diffsim.in, and diffsim_history.in  Also, BASH script for gmt 5 plotting: plot_diffsim.sh
	And, a working gmt5 or gmt6 installation.

VERSION INFO (RECENT not the whole bloody legacy)

13 March 2022
	In examining behavior across PRZ, at higher temperatures, kept seeing residual trapped atoms even at high T (400 C!!).
	Initially suspected this was related to number of jumps. Saw that expected jumps would exceed max value of long,
	so changed jump-related variables to unsigned long long. Thus needed to add some type casts as well, not just declarations.
	Added a warning message if user runs at temperatures that will blow the unsigned long long limit; capped jumps at that limit
	(which could be dodgy).

	That helped... but was still getting those refractory ~3400 still-trapped walkers. Bugger!

Version 3.13:
	PROBLEM UNDERSTOOD (after fixing some small bugs and handling case of large jump numbers):
	With coarser geologic time steps that experience radiogenic production, was getting some residual trapping even with large number
	of jumps. Reason was, because we only allow escape once per time interval, for each chunk of production all should escape
	at high temperatures but some will be retrapped until next interval(s). So for last time interval or two, a residual number
	of atoms were remaining trapped because of re-trapping. Decreasing production rate and interval means at the end, a smaller
	proportion of total atoms are produced in last interval or two that are subject ot this effect. In the limit, if production was
	1 and timesteps short but numerous, the problem would be miniscule, but code will be very slow (it would be like allowing
	escape from trap at each new jump). 
	
	So... fix is to permit more geotimenodes and lower production, and run code this way.  
	
 	Fixed small NODES-1 bug ( in one line of code); changed long to unsigned long long for jump variables;
 	added warning if too many jumps and capped these higher-T cases at just under max unsigned long long.
 
 Version 3.14:
 	Things working better but noticed old persistent issues: bookkeeping variables kept recording some small negative
 	numbers for trapped and lost atoms. Tedious testing suggested it might be related to race condition and somehow,
 	logic allowing a few atoms to be lost twice.
 	
 	Simplified code by removing most of the tracking for things like re-trapping, etc,, and changed logic slightly for
 	what atoms to process. After all these changes, tested the atoms-lost variables and found that parallel block was now working
 	correctly using reduction clauses. 
 	
 	Clean up reporting to be simpler and easier to read; deactivated tracking files which would never or rarely be used but
 	approached 10 MB in size, per run!
*/

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstring>
#include <unistd.h>
#include <vector>
#include <sys/stat.h>
#include <cstdint>
#include <random>
#include <iostream>
#include <chrono>
#include "pcg_random.hpp" // needed for RNG; we need a good one for this code!
#include <omp.h>

using namespace std; 

// Define some parameters as fixed.
#define MAXWALKERS 1000000    // be sure number of walkers is not too high; use for dimensioning vectors
#define MAXTRAPS 10001        // be sure number of traps is not too high; use for dimensioning vectors
#define MAXTRAPTYPES 10       // place a limit on number of trap types
#define MAXTIMENODES 100001   // establish a limit for number of time nodes
#define MAXGRIDNODES 1000     // establish a limit for number of grid nodes
#define MAXPRODUCTION 100000  // establish limit on production per geologic time step
#define PI 3.14159265

int main(void)
{

// PCG set of RNG from http://www.pcg-random.org
  	//declare most RNG instances here; define one other one later, after getting file input
    pcg_extras::seed_seq_from<std::random_device> seed_source;
    pcg32 rng(seed_source);
    std::uniform_real_distribution<double> uniform_dist2(0.0,1.0);
	
// I/O related things
	FILE *ifp, *ofp, *ofp2, *ofp3;
	char newFolder[20];  // was 10 but this segfaulted code because numbered folder names could exceed string length

// items for assessing timing; useful because naive user could make this model run for a billion years
	double started, ended, started_model;
	double elapsed, elapsed_model;

// main variables
	// ...starting with some items that were originally preprocessor macros, but are now inputs from file (hence the legacy all-caps)
	
	long NODES, GEOTIMENODES,PRODUCTION_RATE, NTRAPS;
	
	vector<long> TRAPS(MAXTRAPTYPES); // 	zero-based array
	vector<double> E_TRAP(MAXTRAPTYPES);    // faux "activation energy" use to define probability of escape from sink
	vector<double> SCALE_TEMP(MAXTRAPTYPES);    // scaling factor for sink-escape probability
	
	// more vectors, for locating atoms and tracking their behavior
	vector<long> xposn(MAXWALKERS+1); // current x, y z posn of each atom. 1-based arrays!!
	vector<long> yposn(MAXWALKERS+1);
	vector<long> zposn(MAXWALKERS+1);
	
	vector<long> inc_lab_lost(MAXTIMENODES,0);	// records number of losses from crystal for each time increment

	vector<unsigned long long> jumps(MAXTIMENODES);	// records number of jumps for each time increment
	
	// integer flags for various possible states and fates of walkers
	vector<long> which_trap(MAXWALKERS+1, -1); 	
	vector<long> geo_lost(MAXWALKERS+1, 0); 
	vector<long> geo_trapped(MAXWALKERS+1, 0);
	vector<long> lab_lost(MAXWALKERS+1, 0);
	vector<long> lab_trapped(MAXWALKERS+1, 0);
	vector<long> geo_escaped(MAXWALKERS+1, 0); 
	vector<long> lab_escaped(MAXWALKERS+1, 0); 

// boolean flags that give atom's current status and thus help us avoid needless jumping for irrelevant atoms
	vector<bool> atom_lost(MAXWALKERS+1, false);
	vector<bool> atom_ejected(MAXWALKERS+1, false);
	
// kinetic parameters for volume diffusion
	double Eact; // activation energy for regular volume diffusion through lattice
	double Do;  // value of Do, user-tuned based on radius to produce behavior close to what is observed, e.g. helium in apatite
	
// things for lab model
// generally set heating parameters close to what we use in actual CRH experiments (e.g., 30 C/min, 20 sec integration...)
	
	double start_temp, lab_range;  // start and span of heating for degassing, in ˚C  (usual might be 200 and 900˚C)
	double heating_rate;   // in degrees per second (usual for CRH is 0.5 ˚C/second)
	double integration_time; // seconds, time spent walking/acquiring "signal" per step (usual is 20 seconds)
			
	long inc_time, atom; // main loop indices 
	unsigned long long total_geo_jumps=0, total_lab_jumps=0 ;  // these can get big if T is high
	long itrap, ntrap; // utility loop indices for traps (itrap for traps of same type; ntrap for different trap types)
	
	unsigned long long current_jumps = 0; // number of jumps for current time step
	bool capped_jumps = false;

	// many counters for tracking things
	long total_atoms=0, geo_lost_atoms=0,alpha_ejected_atoms=0,lab_lost_atoms=0, geo_trapped_atoms = 0;
	long lab_trapped_atoms = 0;
	long iproduction;  // utility index for production

	double sphere_loc_double; // exact spherical distance from center
	double ftee = 0.999999; //user-provided Ft; needs to be less than 1.000
	
	double current_temp; // MEAN temperature across current time increment
		
// variables related to trapping
	vector<double> probability(MAXTRAPTYPES, 0.0); // zero-based! Probability that a trapped atom does not jump, for each trap type
	
// ***** STARTUP *****
	
// get inputs from file diffsim.in - use a few assertions to check things, but make no effort to really vet
// what is read - trust the user (!) and figure that usually, bad input will just lead to crash. Caveat emptor.

	ifp = fopen("diffsim.in", "r");
	fscanf(ifp, "%ld", &NODES);  // NODES will be RADIUS of sphere (easiest to interpret this as in cm (!!))
	assert((NODES >= 50) and (NODES <= MAXGRIDNODES));

// Set up RNG used to produce diffusing atoms randomly across the grid
	std::uniform_int_distribution<int> uniform_dist3(-NODES,NODES);  // VITAL - we need full range to get all of sphere, not just positive quadrant!
	
	fscanf(ifp, "%ld", &GEOTIMENODES);

	assert((GEOTIMENODES >= 10) and (GEOTIMENODES <= MAXTIMENODES-1));  // low values below 100 will increasingly lead to inaccuracies 
	
	fscanf(ifp, "%ld", &PRODUCTION_RATE);
	assert((PRODUCTION_RATE >= 1) and (PRODUCTION_RATE <= MAXPRODUCTION));
	
	fscanf(ifp, "%lf", &Do); // trust user not to enter stupid values
	fscanf(ifp, "%lf", &Eact); // calories per mol
	
// this input block will be variable in length to accomodate different sink types; this breaks compatibility with input files for v.2 and older
	fscanf(ifp, "%ld", &NTRAPS);
	assert(NTRAPS <= MAXTRAPTYPES);
	for (ntrap = 0; ntrap < NTRAPS; ntrap++)
	{
		fscanf(ifp, "%ld%lf%lf",&TRAPS[ntrap], &E_TRAP[ntrap], &SCALE_TEMP[ntrap]); // #traps, cal/mol, ˚C
		assert(TRAPS[ntrap] < MAXTRAPS);
	}

	fscanf(ifp, "%lf", &start_temp); // ˚C
	fscanf(ifp, "%lf", &lab_range); // ˚C
	fscanf(ifp, "%lf", &heating_rate); // ˚C per second
	fscanf(ifp, "%lf", &integration_time); // seconds
	fscanf(ifp, "%lf", &ftee);  // sample ftee; used to calculate faux spherical stopping distance so must be < 1.0000
	assert((ftee >= 0.4) and (ftee < 1.0)); 
	
	fclose(ifp);

	assert (GEOTIMENODES * PRODUCTION_RATE < MAXWALKERS + 1); // make sure numbers of walkers isn't greater than maximum allowed
	
// calculate some things that depend on input from parameter file diffsim.in

	double dTemp_lab = heating_rate * integration_time;  // temperature increment for CRH-style lab heating history
	long labsteps = static_cast<long> (lab_range) / dTemp_lab;  // number of lab heating steps
	double dtlab = integration_time; 
	
// finally, declare arrays that needed input about traps
	long xposnTR[NTRAPS][MAXTRAPS+1]; // x, y, z posn of each trap for each trap type. 1-based arrays!!
	long yposnTR[NTRAPS][MAXTRAPS+1];
	long zposnTR[NTRAPS][MAXTRAPS+1];

// now get the input thermal history (from file diffsim_history.in)

	long ttpairs_in;
	ifp = fopen("diffsim_history.in", "r");

	fscanf(ifp, "%ld", &ttpairs_in);		// oldest pair first
	assert ((ttpairs_in > 1) && (ttpairs_in <= MAXTIMENODES));  // need two pairs at least, but can't have too many

	vector<double> intime(ttpairs_in);
	vector<double> intemp(ttpairs_in);
	
	for (inc_time = 0; inc_time < ttpairs_in; inc_time++)
	{
		fscanf(ifp, "%lf%lf",&intime[inc_time], &intemp[inc_time]);
	}
	fclose(ifp);

// Now discretize the input thermal history, interpolating modeltime[] and modeltemp[] into intime[] and intemp[]
// We do this by simply using a constant delta-time. A constant delta-temperature is far better in apportioning time nodes
// among segments of different rate, but for this code, we'd prefer to have easy control of, and a limit to, the number of time steps).

	long ttpoints = 0, segment;
	double geo_timestep = intime[0] / GEOTIMENODES, segtime_diff, slope;
	
	vector<double> modeltemp(GEOTIMENODES+1);
	vector<double> modeltime(GEOTIMENODES+1);

// first assign the times to modeltime[]

	for (inc_time = 0; inc_time < GEOTIMENODES; inc_time++)
	{
		modeltime[inc_time] = intime[0] - inc_time * geo_timestep;
	}
	modeltime[GEOTIMENODES] = 0.0;  // make certain the end of model is at 0 m.y.

// now, for each segment get a temperature for each modetime[] it contains	
	inc_time = 1;
	
	for (segment = 1; segment <= ttpairs_in - 1; segment++) //step through segments
	{
		segtime_diff = intime[segment-1] - intime[segment];
		assert(segtime_diff >= geo_timestep);
	
		slope = (intemp[segment-1] - intemp[segment]) / segtime_diff;

		while (modeltime[inc_time] > intime[segment])
		{
			modeltemp[inc_time] = intemp[segment-1] - slope * (intime[segment-1] - modeltime[inc_time]);
			inc_time++;
		}
	}

	// Make certain start and end values match the input values exactly
	modeltemp[0] = intemp[0];
	modeltemp[GEOTIMENODES] = intemp[ttpairs_in - 1];
	
	double dtgeo = intime[0] / GEOTIMENODES * 3.15576e13; // geologic time step in seconds

// make a results directory and change to it
	int j = 0;	
	do
	{
		if (j == 0)
		{
			sprintf(newFolder,"RESULTS");		
		}
		else     // don't overwrite an older folder, so rename by adding a sequential digit
		{
			sprintf(newFolder,"RESULTS-%d", j);
		}
		j++;
	} while (mkdir(newFolder, 0755 ) == -1); 

/* change to new folder */
	if( chdir( newFolder) )
	{
		printf("\nCannot change to new folder\n");
		exit(EXIT_FAILURE); 
	}

// ***** BEGIN MAIN CODE STARTING GEOLOGICAL MODEL *****

	printf("\n");
	printf("+++++++++++++++++++++++++++  PROGRAM diffsim 3.14 +++++++++++++++++++++++++++\n");

	printf("PROCESSING %4ld ATOMS: \n\n",GEOTIMENODES * PRODUCTION_RATE);
	printf("1. GEOLOGICAL STAGE\n");
	
	ofp2=fopen("model_history.txt","w");  // file to record information about model run
	
	fprintf(ofp2,"\n");
	fprintf(ofp2,"+++++++++++++++++++++++++++  PROGRAM diffsim 3.14  +++++++++++++++++++++++++++\n");

	fprintf(ofp2,"PROCESSING %4ld ATOMS: \n\n",GEOTIMENODES * PRODUCTION_RATE);
	fprintf(ofp2,"1. GEOLOGICAL STAGE\n");

// first set up timing for geological run through time and across all atoms and their jumps
//	started = clock();
	started = started_model = omp_get_wtime();  // need this version for parallel code

// MAKE TRAPS
// Don't worry about duplicate trap locations as this will be unlikely, and if it happens, no big deal given how this code works.
// In diffsim version 3, we need to do this in loop, making the requested number of traps for each type.
	for (ntrap = 0; ntrap < NTRAPS; ntrap++)
	{
		itrap=0;
		do
		{
			itrap++;
			
			xposnTR[ntrap][itrap] = uniform_dist3(rng);  // should give random integer between -NODES and NODES
			yposnTR[ntrap][itrap] = uniform_dist3(rng);	
			zposnTR[ntrap][itrap] = uniform_dist3(rng);

			sphere_loc_double = sqrt(xposnTR[ntrap][itrap]*xposnTR[ntrap][itrap] + yposnTR[ntrap][itrap]*yposnTR[ntrap][itrap]+ zposnTR[ntrap][itrap]*zposnTR[ntrap][itrap]);	// radial location
			if (sphere_loc_double > static_cast<double>(NODES)) (itrap--);	// if radial location > radius in nodes, point not in crystal  //was, incorrectly,  NODES-1 in 3.12
		} while ((itrap <= TRAPS[ntrap]));
	}	

// CALCULATE STOPPING
// calculate the stopping distance (spherical geometry) based on the number of nodes (units of nodes) and user-supplied ftee
	double inclination, azimuth;
	double stopradius;
	stopradius = static_cast<double> (NODES);
	long i_nr;
	double stopping = 20.;
  
// do a quick Newton Raphson to get stopping distance from analytical formula for spherical Ft
	for (i_nr=0;i_nr<10;i_nr++)
	{
		stopping = stopping - (1./16./stopradius/stopradius/stopradius*stopping*stopping*stopping - 3./4./stopradius*stopping + 1 - ftee)/(3./16./stopradius/stopradius/stopradius*stopping*stopping - 3./4./stopradius);
	}
	// bit kludgy, but be sure stopping is positive (N-R can leave slightly negative stopping if Ft is set to 1.0)
	if (stopping < 0.0) { stopping = 0.0;}

// ***** MAIN GEOLOGICAL TIME LOOP *****

	ofp=fopen("geological_history.txt","w");  // file to record geological thermal history and various metrics as function of time
	
	for (inc_time = 1; inc_time <= GEOTIMENODES; inc_time++)  // 1-based!!
	{	
		fflush(stdout); //sets up printing of non-scrolling iteration monitor
		printf("\r");  // have to put fflush(stdout) at start of main loop to make this work
		printf("   ...processing tT increment: %4ld",inc_time);

		current_temp = modeltemp[inc_time];

// CRITICAL!!! get number of jumps for this time increment, using Einstein relationship inserted into Arrhenius law, with jump distance being 1 (grid unit)
//                        n = 6Dt/lamda2  where lamda=1

// add a safety check to be sure that jumps per interval does not exceed max value for unsigned long long	
		if (Do * 6. * dtgeo * exp(-Eact * 0.50327/(current_temp + 273.15)) < 1.84e19)
		{
			jumps[inc_time] = current_jumps = static_cast<unsigned long long> (Do * 6. * dtgeo * exp(-Eact * 0.50327/(current_temp + 273.15) ) ); 
		}
		else
		{
			jumps[inc_time] = current_jumps = static_cast<unsigned long long> (1.84e19); 
			capped_jumps = true;
		} 
		total_geo_jumps = total_geo_jumps + current_jumps; // tally max total jumps in geological model for an atom that is never trapped

// jump distance is 1 grid node - our faux Do is scaled to this

//RADIOGENIC PRODUCTION
// For each time increment, make some atoms in the amount of PRODUCTION_RATE, recording their random starting locations.
// Creation is across uniform cube; need to then clip out those atoms created outside the inscribed sphere and iterate until we reach specified production number
		iproduction = 0;
		do
		{
			iproduction++;
			total_atoms++; // keep running and growing count of total atoms produced
			xposn[total_atoms] = uniform_dist3(rng);  // should give random integer between -NODES and NODES
			yposn[total_atoms] = uniform_dist3(rng);
			zposn[total_atoms] = uniform_dist3(rng); 
		
			sphere_loc_double =  sqrt(static_cast<double>(xposn[total_atoms]*xposn[total_atoms] + yposn[total_atoms]*yposn[total_atoms]+ zposn[total_atoms]*zposn[total_atoms]) );	// radial location

			if (sphere_loc_double  <= static_cast<double> (NODES))	// if radial location <= radius in nodes, point is in sphere, so now do ejection
			{
				// now add in alpha ejection
				inclination = acos(1.0 - 2.0 * uniform_dist2(rng)); // need to be careful to properly spherically randomize ejection vector
				azimuth = 2. * PI * uniform_dist2(rng);             // this code snippet comes from PKZ code ftee.c

				xposn[total_atoms] = xposn[total_atoms] + static_cast<long>  (round(stopping * sin(inclination) * cos(azimuth))); 
				yposn[total_atoms] = yposn[total_atoms] + static_cast<long>  (round(stopping * sin(inclination) * sin(azimuth)));
				zposn[total_atoms] = zposn[total_atoms] + static_cast<long>  (round(stopping * cos(inclination)));
				
				sphere_loc_double = sqrt(static_cast<double> (xposn[total_atoms]*xposn[total_atoms] + yposn[total_atoms]*yposn[total_atoms]+ zposn[total_atoms]*zposn[total_atoms])) ;
				// now check to see if new location after ejection is in crystal
				if (sphere_loc_double  <= static_cast<double> (NODES))	// if radial location <= radius in nodes, atom is still in sphere so then check for trapping
				{
					for (ntrap=0; ntrap<NTRAPS; ntrap++)
					{
						for (itrap=1; itrap<=TRAPS[ntrap]; itrap++)
						{
							if ((xposn[total_atoms]==xposnTR[ntrap][itrap])&&(yposn[total_atoms]==yposnTR[ntrap][itrap])&&(zposn[total_atoms]==zposnTR[ntrap][itrap]))
							{
								which_trap[total_atoms] = ntrap; //record type of trap this specific atom is in
							}	
						}
					}	
				}
				else  // after alpha emission atom is out of sphere, 
				{
					alpha_ejected_atoms++;
					atom_ejected[total_atoms] = true; // record which atoms are gone via ejection
				}	
			}
			else   // atom produced was not in sphere, so try again to make another one
			{
				iproduction--;
				total_atoms--;
			}	

		} while (iproduction < PRODUCTION_RATE);  // keep going until all produced atoms are in the spherical crystal (before ejection)

// ESCAPE PROBABILITIES FOR THIS TIME STEP	
// Get probability that a trapped atom stays there at current temperature.
// To get p, use Boltzmann-like distribution scaled by a faux partition function, faux because we use an empirical
// temperature to scale the location of this probability in temperature, rather than integrating across all possible energy states

// We interpret p as probability that atom has E_TRAP energy or higher, and can therefore jump. 

// We also scale probability by multiplying by dtgeo to account for greater time span available in geological setting.
// This is very empirical! In reality other functions might apply!
		for (ntrap=0; ntrap<NTRAPS; ntrap++)
		{
			probability[ntrap] = dtgeo * exp(-E_TRAP[ntrap] * 0.50327 / (273.15 + current_temp) ) / exp(-E_TRAP[ntrap] * 0.50327 / (273.15 + SCALE_TEMP[ntrap] ) );
		}

// ***** MAIN ATOM LOOP *****
	#pragma omp parallel num_threads(omp_get_max_threads())  // key OpenMP pragma; it's parameter used to get procs()
	{
    	pcg_extras::seed_seq_from<std::random_device> seed_source;  // PZ _thinks_ this makes the RNG safe for each thread.
    	pcg32 rng(seed_source);
		std::uniform_int_distribution<int> uniform_dist(1, 6); // crucial for core jump routine
		std::uniform_real_distribution<double> uniform_dist2(0.0,1.0);
		
 	    unsigned long long jump;
	    double sphere_loc_double;
	    
    	#pragma omp for schedule(static,3) nowait  reduction(+:geo_lost_atoms)
			for (atom = 1; atom <= total_atoms; atom++) // now loop through atoms, jumping only those that are not lost or trapped or ejected. 1-based!
			{
			
			// ***** MAIN INDIVIDAL-WALKER JUMP LOOP *****  

				if ( ( atom_ejected[atom] == false) && (geo_lost[atom] < 1 ) ) // only keep walking if this atom is still in crystal
				{
					jump = 1; // initialize counter for loop
				
					if (which_trap[atom] > -1)   // give trapped atoms a chance to escape, but only once at start of jumping sequence --
													 // we might want to check this at every jump increment BUT code will REALLY slow down
													 // and escapes will be too common, so now we are just relatively scaling the probability
													 // based on length of geological or lab time increment
					{
						if (uniform_dist2(rng)  <= probability[which_trap[atom]])  // got a random value between 0 and 1; if < p, then escape. This maps a fractional probability to a concrete boolean decision to jump or not.
						{
							which_trap[atom] = -1; // flag atom as not in any trap
						}
					}
					
					if (which_trap[atom] == -1) // atom is not in trap, so let it jump normally
					{
						while ((jump < current_jumps) && (geo_lost[atom] < 1 ) && (which_trap[atom] == -1))  // this is the jumping loop; need a do-while structure to facilitate special cases
						{	
							switch (uniform_dist(rng)) // make a jump of 1 increment, im one of 6 directions, and check to see if it is still in crystal
							{
							case 1:
								xposn[atom]++;
								break;
							case 2:
								xposn[atom]--;
								break;			
							case 3:
								yposn[atom]++;
								break;					
							case 4:
								yposn[atom]--;		
								break;
							case 5:
								zposn[atom]++;
								break;
							case 6:
								zposn[atom]--;					
								break;			
							default:
								printf("disaster! somehow, bad jump choice\n");
							}
							sphere_loc_double =  sqrt(static_cast<double>(xposn[atom]*xposn[atom] + yposn[atom]*yposn[atom]+ zposn[atom]*zposn[atom])) ;	// radial location
							if (sphere_loc_double > static_cast<double>(NODES)) // atom is outside of crystal
							{
								geo_lost[atom]++;   // increment escape counter (should only happen once for this counter!)
								geo_lost_atoms++;
							}
							else // atom is within crystal
							{
							// if in crystal, now check to see if this jump was into a trap

								for (long ntrap=0; ntrap<NTRAPS; ntrap++)
								{
									for (long itrap=1; itrap<=TRAPS[ntrap]; itrap++)
									{
										if ((xposn[atom]==xposnTR[ntrap][itrap])&&(yposn[atom]==yposnTR[ntrap][itrap])&&(zposn[atom]==zposnTR[ntrap][itrap]))
										{
											which_trap[atom] = ntrap; //record type of trap this specific atom is in 						
										}	
									}
								}	
							}
							jump++;
						
						}  // END OF JUMPING WHILE LOOP/
					
					} //END OF IF-NOT-TRAPPED 
	
				} // END OF IF-IN-CRYSTAL CLAUSE
		
			} // END OF ATOM LOOP
			
		} // end of parallel region

// record info about geological portion of model

		fprintf(ofp,"%4ld\t%7.2f\t%7.2f\t%ld\t%ld\t%llu\n",inc_time,modeltime[inc_time],current_temp, total_atoms, geo_lost_atoms, current_jumps);
		
	} // END OF GEOLOGICAL TIME LOOP
	
	fclose(ofp);

// get some need stats about trapped walkers

	for (atom = 1; atom <= total_atoms; atom++) // 
	{
		if (which_trap[atom] > -1) geo_trapped_atoms++;
	}

	printf("\n\nGrid nodes (radius, cm): %ld   Geo-timenodes: %ld\n",NODES,GEOTIMENODES);
	printf("Ea %6.0f;   Do %8.4e;\n",Eact, Do);
	printf("Trap      N     E-trap  Tscale\n");
	for (ntrap=0; ntrap < NTRAPS; ntrap++)
	{
		printf("%2ld\t%4ld\t%6.0f\t%4.0f\n",ntrap, TRAPS[ntrap], E_TRAP[ntrap], SCALE_TEMP[ntrap]);
	}
	printf("Ft supplied: %5.3f; Ft model: %5.3f; stopping (cm): %7.3f\n",ftee, 1.0 - static_cast<double>(alpha_ejected_atoms) / total_atoms, stopping);

	fprintf(ofp2,"\n\nGrid nodes (radius, cm): %ld Geo-timenodes: %ld\n",NODES,GEOTIMENODES);
	fprintf(ofp2,"Ea %6.0f; Do %8.4e;\n",Eact, Do);
	fprintf(ofp2,"Trap      N     E-trap  Tscale\n");
	for (ntrap=0; ntrap < NTRAPS; ntrap++)
	{
		fprintf(ofp2,"%2ld\t%4ld\t%6.0f\t%4.0f\n",ntrap, TRAPS[ntrap], E_TRAP[ntrap], SCALE_TEMP[ntrap]);
	}
	fprintf(ofp2,"Ft supplied: %7.5f; Ft model: %7.5f; stopping (cm): %7.3f\n",ftee, 1.0 - static_cast<double>(alpha_ejected_atoms) / total_atoms, stopping);

// We're done with the geological simulation.
//	ended = clock();
	ended = omp_get_wtime();
	elapsed = (double) (ended - started);
	
/*	
	ofp=fopen("geo_walker_summary.txt","w");  // large debug file to record final walker status and location
	for (atom = 1; atom <= total_atoms; atom++)
	{
//		if((atom_ejected[atom] == false)&&(atom_lost[atom] == false))
//		if((atom_ejected[atom] == false)&&(atom_lost[atom] == false))
		{
			fprintf(ofp,"%4ld\t%4ld\t%4ld\t%6ld\t%6ld\t%6ld\t%s\t%ld\t%s\n",xposn[atom],yposn[atom],zposn[atom],geo_lost[atom],geo_trapped[atom],geo_escaped[atom],atom_lost[atom] ? "true" : "false",which_trap[atom],atom_ejected[atom] ? "true" : "false");
		}
	}	

	fclose(ofp);
*/

	double age_good, age_total, fraction_good;
	
	age_good = static_cast<double> ( (total_atoms - geo_lost_atoms - geo_trapped_atoms - alpha_ejected_atoms) )/total_atoms * intime[0];
	age_total = static_cast<double>( (total_atoms - geo_lost_atoms - alpha_ejected_atoms) )/total_atoms * intime[0];
//	fraction_good = static_cast<double> ( (total_atoms - geo_lost_atoms - geo_trapped_atoms - alpha_ejected_atoms) )/(total_atoms - geo_lost_atoms - alpha_ejected_atoms);
	
// find what segment the good numerical age lies on
	double seg_age = intime[0];
	double kludge_age = age_good;
	if (age_good <= 0.0) kludge_age = 0.1; // if totaal age is zero or negative, interpolation routine will fail an lead to segmentation fault
	
	long i = 0;

	while (seg_age >= kludge_age/ftee)
	{
		i = i+1;
		seg_age = intime[i];       // when done, age should be between indices i and i-1
	}

// interpolate to find the temperature at this time
	double Tc_num = intemp[i] + (intemp[i-1] - intemp[i])*(kludge_age/ftee - intime[i])/(intime[i-1] - intime[i]);

// calculate the local cooling rate at this time
	double coolrate = (intemp[i-1] - intemp[i])/(intime[i-1] - intime[i]);

// calculate the Dodson closure temperature using this cooling rate
	double Tc_dodson = 473.;
	for (i = 1;i <= 20;i++)
	{
			Tc_dodson = Eact/ 1.9859 / log(55 * 1.0e6*365.25*24.0*3600.0 * Tc_dodson * Tc_dodson * Do * 1.987 / Eact/static_cast<double> (NODES)/static_cast<double> (NODES)/coolrate);
	}
	Tc_dodson = Tc_dodson - 273.15;	
	
// send reports to console and to file	
	printf("\n***** Geological model done!    Total CPU time was %6.2fs *****\n",elapsed);

	printf("\t         Total walkers produced: %7ld \n",total_atoms);
	printf("\t        Total walkers remaining: %7ld \n",total_atoms-geo_lost_atoms-alpha_ejected_atoms);
	printf("\t Total walkers lost by ejection: %7ld\n",alpha_ejected_atoms);
	printf("\tTotal walkers lost by diffusion: %7ld\n",geo_lost_atoms);
	printf("\t    Remaining walkers untrapped: %7ld\n",total_atoms - geo_lost_atoms - geo_trapped_atoms - alpha_ejected_atoms);	
	printf("\t     Walkers remaining in traps: %7ld\n",geo_trapped_atoms);
	if (capped_jumps == true)
	{
		printf("\t !!!!! WARNING !!!!! Excess jumps of more than 1.84e19; jumps capped at that value. Be suspicious of results\n");		
	}
	printf("                 Total geological jumps: %8.3e\n\n",static_cast<double>(total_geo_jumps));
	
	printf("     Total age: %7.3f Ma   Ft-corrected: %7.3f Ma\n",age_total,age_total/ftee);	
	printf("     Dodson Tc: %6.2f ˚C    Numerical Tc: %6.2f ˚C\n\n",Tc_dodson,Tc_num);

	fprintf(ofp2,"\n***** Geological model done!   Total CPU time was %6.2fs *****\n",elapsed);

	fprintf(ofp2,"\t         Total walkers produced: %7ld \n",total_atoms);
	fprintf(ofp2,"\t        Total walkers remaining: %7ld \n",total_atoms-geo_lost_atoms-alpha_ejected_atoms);
	fprintf(ofp2,"\t Total walkers lost by ejection: %7ld\n",alpha_ejected_atoms);
	fprintf(ofp2,"\tTotal walkers lost by diffusion: %7ld\n",geo_lost_atoms);
	fprintf(ofp2,"\t    Remaining walkers untrapped: %7ld\n",total_atoms - geo_lost_atoms - geo_trapped_atoms - alpha_ejected_atoms);	
	fprintf(ofp2,"\t     Walkers remaining in traps: %7ld\n",geo_trapped_atoms);
	if (capped_jumps == true)
	{
		fprintf(ofp2,"\t !!!!! WARNING !!!!! Excess jumps of more than 1.84e19; jumps capped at that value. Be suspicious of results\n");		
	}
	fprintf(ofp2,"                 Total geological jumps: %llu\n\n",total_geo_jumps);
	
	fprintf(ofp2,"     Total age: %7.3f Ma   Ft-corrected: %7.3f Ma\n",age_total,age_total/ftee);	
	fprintf(ofp2,"     Dodson Tc: %6.2f ˚C    Numerical Tc: %6.2f ˚C\n\n",Tc_dodson,Tc_num);

// *****************************************************************************************************************
/*
	The following code is meant to outgas any remaining atoms using a CRH-style
	lab heating schedule. Since this code is short and simple I've made no effort
	to be clever and build reusable functions, so the core walking code is just duplicated from above.
	
	This does mean that any repairs or upgrade to the core simulation at the geological stage will need
	to be duplicated in the following lab code!!!!

	Key differences in the following code are that we ignore radiogenic production
	and we need to do the bookkeeping to keep track of atoms lost during lab heating as the model progresses, etc.
*/

// *****************************************************************************************************************

// set up model and main time loop

// first set up timing for lab run through time and across atoms and their jumps 
//	started = clock();
	started = omp_get_wtime();
// ***** MAIN LABORATORY TIME LOOP *****

	printf("2. LABORATORY (CRH) STAGE\n");
	fprintf(ofp2,"2. LABORATORY (CRH) STAGE\n");

	for (inc_time = 1; inc_time <= labsteps; inc_time++)
//	for (inc_time = 1; inc_time <= 1; inc_time++)  // single iteration for f-loss testing
	{
		current_temp = start_temp + inc_time * dTemp_lab - dTemp_lab * 0.5;  // average temperature for time increment
//		current_temp = 450.;  // fixed temperature for loss testing

		fflush(stdout); //sets up printing of non-scrolling iteration monitor
		printf("\r");  // had to put fflush(stdout) at start of main loop to make this work
		printf("   ...processing temperature step: %6.1f",current_temp);
		
// get number of jumps for this time increment
		jumps[inc_time] = current_jumps = static_cast<unsigned long long> (Do * 6 * dtlab * exp(-Eact * 0.50327/(current_temp + 273.15) ) ); 
		total_lab_jumps = total_lab_jumps + current_jumps;

// get probability that trapped atom stays there at current temperature. Multiply by lab duration to scale to reflect lab heating schedule
		for (ntrap=0; ntrap<NTRAPS; ntrap++)
		{
			probability[ntrap] = dtlab * exp(-E_TRAP[ntrap]  * 0.50327 / (273.15 + current_temp) ) / exp(-E_TRAP[ntrap]  * 0.50327 / (273.15 + SCALE_TEMP[ntrap] ) );
		}

		// ***** MAIN ATOM LOOP *****
		#pragma omp parallel num_threads(omp_get_max_threads())
		{
			pcg_extras::seed_seq_from<std::random_device> seed_source;
			pcg32 rng(seed_source);
			std::uniform_int_distribution<int> uniform_dist(1, 6); // crucial for core jump routine
			std::uniform_real_distribution<double> uniform_dist2(0.0,1.0);
			unsigned long long jump;
			double sphere_loc_double;
	    
   			#pragma omp for schedule(static,3) nowait reduction(+:lab_lost_atoms)
			for (atom = 1; atom <= total_atoms; atom++) // now loop through atoms, jumping those that are not lost or trapped
			{
			// ***** MAIN INDIVIUDAL WALKER LOOP *****

				if ((geo_lost[atom] < 1) && (atom_ejected[atom] == false) && (lab_lost[atom] < 1)) // only keep walking if atom is still in crystal
				{
					jump = 1; // start jump counter for jump loop

					if (which_trap[atom] > -1)   // give trapped atoms a chance to escape and join the jumping pool
					{
						if (uniform_dist2(rng) <= probability[which_trap[atom]])
						{
							which_trap[atom] = -1; // atom is no longer in a trap
						}
					}
				
					if (which_trap[atom] == -1) // atom is not in trap, so let it jump normally
					{
						while ((jump < current_jumps) && (lab_lost[atom] < 1) && (which_trap[atom] == -1) )
						{	
							switch (uniform_dist(rng)) // make a jump of 1 increment, and check to see if it is still in crystal
							{
							case 1:
								xposn[atom]++;
								break;
							case 2:
								xposn[atom]--;
								break;			
							case 3:
								yposn[atom]++;
								break;					
							case 4:
								yposn[atom]--;		
								break;
							case 5:
								zposn[atom]++;
								break;
							case 6:
								zposn[atom]--;					
								break;			
							default:
								printf("disaster! somehow, bad jump choice\n");
							}
							sphere_loc_double =  sqrt(static_cast<double>(xposn[atom]*xposn[atom] + yposn[atom]*yposn[atom]+ zposn[atom]*zposn[atom]));	// radial location
							if (sphere_loc_double > static_cast<double> (NODES)) // atom is outside of crystal
							{
								lab_lost[atom]++; // should only trigger once to value of 1
								lab_lost_atoms++;
							}
							else // atom is within crystal
							{					
								for (long ntrap=0; ntrap<NTRAPS; ntrap++)  // did it jump into trap?
								{
									for (long itrap=1; itrap<=TRAPS[ntrap]; itrap++)
									{
										if ((xposn[atom]==xposnTR[ntrap][itrap])&&(yposn[atom]==yposnTR[ntrap][itrap])&&(zposn[atom]==zposnTR[ntrap][itrap]))
										{
										which_trap[atom] = ntrap; //record type of trap this specific atom is in
										}	
									}
								}
							}
							jump++;
							
						} // END OF JUMPING DO WHILE LOOP
					
					} // END OF IF-NOT-TRAPPED CLAUSE
	
				} // END OF IF-IN-CRYSTAL IF CLAUSE	
		
			} // END OF ATOM LOOP
		
		} //end parallel block
		
		inc_lab_lost[inc_time] = lab_lost_atoms; //need this record of progressive loss to simulate CRH release
	} // END OF LABORATORY TIME LOOP

// get some need stats about any remaining trapped walkers
	for (atom = 1; atom <= total_atoms; atom++) // 
	{
		if (which_trap[atom] > -1) lab_trapped_atoms++;
	}

// Now do CRH data reduction
	ofp=fopen("lab_history_CRH.txt","w");  // main output file  to record lab phase plus CRH simulation
	ofp3=fopen("../temp.out","w");  // for plot script, temporary plot file to record T, df, 1e4/K, lnD/a2
	
	double df_per_C;
	double nowT,recipT, lnda2, floss, fprev;
	lab_escaped[0] = 0;
	fprev = 0.0;
		
	for (inc_time = 1; inc_time <= labsteps; inc_time++)
	{
		df_per_C = (inc_lab_lost[inc_time]-inc_lab_lost[inc_time-1])/(dTemp_lab)/static_cast<double>(lab_lost_atoms);
		nowT = (start_temp + inc_time * dTemp_lab - dTemp_lab * 0.5);
		recipT = 10000./(nowT + 273.15);
		floss = static_cast<double> (inc_lab_lost[inc_time])/lab_lost_atoms;
		
		if ((floss > 0.0) && (floss < 1.0)) // only calculate Arrhenius data if we have reasonable f values
		{
			if (floss < 0.8712)
			{
				lnda2 = log(1/(dtlab) * ( -0.33333333 * (floss - fprev) - 2. / PI * (sqrt(1-PI/3.* floss) - sqrt(1-PI/3. * fprev))));
			}
			else
			{
				lnda2 = log(1/PI/PI/dtlab * log((1. - fprev)/(1. - floss)));
			}
			fprev = floss;
		}
		if (floss <= 0.0) { lnda2 = -44.4444; }  // crudely set flag to indicate bad input values, using distinctively odd values
		if (floss >= 1.0) { lnda2 = 44.4444; }

		fprintf(ofp,"%3ld\t%7.0f\t%9.5f\t%9.6f\t%8.6f\t%ld\t%lld\t%7.4f\t%7.3f\t%6.1f\t%7.5f\t%6.4f\n",
		inc_time,
		(inc_time * dtlab - 0.5*dtlab),
		nowT,
		df_per_C,
		floss,
		inc_lab_lost[inc_time]-inc_lab_lost[inc_time-1],
		jumps[inc_time],
		recipT,
		lnda2,
		nowT,
		floss,
		dtlab/60.);
		
		fprintf(ofp3,"%9.5f\t%9.6f\t%7.4f\t%7.3f\n",nowT,df_per_C,recipT,lnda2);	
	}
	
	fclose(ofp);
	fclose(ofp3);	
	
//	ended = clock();
	ended = omp_get_wtime();
	elapsed = static_cast<double> (ended - started);
	elapsed_model = static_cast<double> (ended - started_model);
	
// send lab-heating report to console and file
	
	printf("\n\n***** Lab model done!         Total CPU time was  %6.2fs *****\n",elapsed);
	printf("\t      Lab heating rate (˚C/min):  %6.2f\n",heating_rate * 60.);	
	printf("\t        Total walkers remaining: %7ld \n",total_atoms - geo_lost_atoms - lab_lost_atoms - alpha_ejected_atoms);	
	printf("\t               Lab walkers lost: %7ld\n",lab_lost_atoms);
	printf("\t Lab walkers remaining in traps: %7ld\n",lab_trapped_atoms);
	printf("                        Total lab jumps: %8.3e\n\n",static_cast<double>(total_lab_jumps) );	

	printf("                             ENTIRE MODEL DONE:   %6.2fs *****\n\n", elapsed_model);
	
	fprintf(ofp2,"***** Lab model done!         Total CPU time was  %6.2fs *****\n",elapsed);
	fprintf(ofp2,"\t      Lab heating rate (˚C/min):  %6.2f\n",heating_rate * 60.);	
	fprintf(ofp2,"\t        Total walkers remaining: %7ld \n",total_atoms - geo_lost_atoms - lab_lost_atoms - alpha_ejected_atoms);	
	fprintf(ofp2,"\t               Lab walkers lost: %7ld\n",lab_lost_atoms);
	fprintf(ofp2,"\t Lab walkers remaining in traps: %7ld\n",lab_trapped_atoms);
	fprintf(ofp2,"                        Total lab jumps: %8.3e\n\n",static_cast<double>(total_lab_jumps) );	

	fprintf(ofp2,"                             ENTIRE MODEL DONE:  %6.2fs *****\n\n", elapsed_model);
	
// report the input thermal history that was discretized
	fprintf(ofp2,"Input thermal history:\n");
	for (inc_time = 0; inc_time < ttpairs_in; inc_time++)
	{
		fprintf(ofp2,"%d\t%6.2f\t%6.2f\n",inc_time,intime[inc_time],intemp[inc_time]);
	}

// report the discretized thermal history	
	fprintf(ofp2,"\nDiscretized thermal history:\n");
	for (inc_time=0;inc_time<=GEOTIMENODES;inc_time++)
	{
		fprintf(ofp2,"%d\t%8.4f\t%8.4f\n",inc_time,modeltime[inc_time],modeltemp[inc_time]);
	}
	fclose(ofp2);
/*	
	ofp=fopen("lab_walker_summary.txt","w");  // debug file to record final walker status and location
	
	for (atom = 1; atom <= total_atoms; atom++)
	{
		if(atom_ejected[atom] == false)
		{
			fprintf(ofp,"%4ld\t%4ld\t%4ld\t%6ld\t%6ld\t%6ld\t%6ld\t%6ld\t%6ld\t%s\t%ld\n",xposn[atom],yposn[atom],zposn[atom],geo_lost[atom],geo_trapped[atom],geo_escaped[atom],lab_lost[atom],lab_trapped[atom],lab_escaped[atom],atom_lost[atom] ? "true" : "false",which_trap[atom]);
		}
	}
	fclose(ofp);
*/	

// Finally, end by using the temp output file to make the plot (both the BASH helper script and these commands have to account
// for the fact we changed to a results directory at start of code)
	string syscall;
	syscall = "../plot_diffsim.sh";
	system(syscall.c_str());
	
// clean up the scratch file
	syscall = "rm -r ../temp.out";
	system(syscall.c_str());
	
	return 0;
}              // END of MAIN()
